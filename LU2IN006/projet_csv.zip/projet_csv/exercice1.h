#ifndef __EXERCICE_1__
#define __EXERCICE_1__

int hashFile(char* source, char* dest);
char* sha256file(char* file);

#endif