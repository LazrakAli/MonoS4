#ifndef _EXERCICE3_
#define _EXERCICE3_

#include "exercice1.h"
#include "exercice2.h"

List* listdir(char* root_dir);

#endif