#include <stdlib.h>
#include <stdio.h>
#include "hachage.h"

int main(){
    //system("ls");
}